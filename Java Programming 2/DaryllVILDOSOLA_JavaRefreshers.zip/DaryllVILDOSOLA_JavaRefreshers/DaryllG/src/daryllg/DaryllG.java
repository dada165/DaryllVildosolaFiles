/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daryllg;

import java.util.Scanner;

/**
 *
 * @author 2ndyrGroupA
 */
public class DaryllG {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner myCode = new Scanner(System.in);
        System.out.println("Input a number: ");
        int num = myCode.nextInt();
        
        String word;
        
        word = 20;
    }
    
}
